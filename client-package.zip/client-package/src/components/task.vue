/* eslint-disable no-console */
/* eslint-disable no-console */
/* eslint-disable no-console */
<template>
  <div>
<h1>shivam parve is here</h1>

<div id="root" class="box">

<input type="text" placeholder="enter the task to be done" v-model="name">
<hr>
<button v-on:click="addTodo" >INSERT</button>

<ul style="list-style-type:none;">
    <li v-for="(todo, todoIndex) in todos" :key="todo.id">

<h4 class="in">
<input type="checkbox" v-on:click="todo.done=!todo.done ; modify(todo,todoIndex)" >

        <del v-if="todo.done==true" style="color:red">{{ todo.title }}
        </del>
        <span v-else> {{ todo.title }}</span>

      <button v-on:click="deleteTodo(todo, todoIndex)">REMOVE</button>

    </h4>
    </li>
  </ul>

</div>


  </div>
</template>
  
<script>

export default {
data() {
    return {
        name:'',
          done:'false',
          completed:'false',

            todos: []
    }
},
        mounted () {
                this.$http.get('/task_list').then(response => {
                    this.todos = response.body;
                    console.log(response.body)
                });
              },

methods:
{
 addTodo:function()
 {
// eslint-disable-next-line no-console
console.log("shivam")
alert('in add todo')

// eslint-disable-next-line no-undef



   this.$http.post('/task', {title: this.name,done:false})
   .then(response => {
                                           console.log('from post method ',response)
                   if(response.status == 201){
                     this.todos.push({id: response.body.todo_id, title: this.name,done:false});
                     this.name=''
                   }
                 }).catch((error)=>{
                     // eslint-disable-next-line no-console
                     console.log('error ',error)
                  
                 });



 },

 modify:function(todo,todoIndex)
 {


   this.$http.put('todo/'+todo.id, {id: todo.id, title: todo.title, done: todo.done}).then(response => {
             if(response.status == 200){
               this.todos[todoIndex].done =todo.done ;
             }
           });


 },

 deleteTodo(todo, todoIndex){

if (todo.done) {
  this.$http.delete('todo/'+todo.id).then(response => {
    if(response.status == 200){
      this.todos.splice(todoIndex, 1);
      this.name=''
    }
  });

}
else {
  alert("you are not done with this task, if you have completed it please mark it and then remove")
}
}



}

}
</script>

<style>
  .back
            {
            width:500px;
            height:100px;
            color:grey;
            background-color:yellow;
            display: inline-block;

            

            }
            .del {
                      text-decoration: line-through;
                  }
            .box
            {
              width:500px;
             height:900px;
             background-color:	#D3D3D3;
             display: inline-block;
             margin: 10px;
             padding-top: 10px;
             padding-left: 10px;
            border-color: red;
            border-style: solid;
            border-width: 2px;
            }

            .in
            {
              background-color: #FFFFE0;
            padding: 5px;

            }
            input[type=checkbox]:checked + label {
            color:red;
            text-decoration: line-through;
}

</style>
